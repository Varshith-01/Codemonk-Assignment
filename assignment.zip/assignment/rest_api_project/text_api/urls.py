from .views import UserListView, ParagraphListView, WordIndexListView
from django.urls import path
from .views import CustomUserDetail, WordSearch

urlpatterns = [
    # Endpoint for retrieving a specific user's details
    path('api/user/<int:pk>/', CustomUserDetail.as_view(), name='user-detail'),

    # Endpoint for searching words in paragraphs
    path('api/wordsearch/', WordSearch.as_view(), name='word-search'),

    # Endpoint for listing all users
    path('api/users/', UserListView.as_view(), name='user-list'),

    # Endpoint for listing and creating paragraphs
    path('api/paragraphs/', ParagraphListView.as_view(), name='paragraph-list'),

    # Endpoint for listing word indexes
    path('api/wordindexes/', WordIndexListView.as_view(), name='wordindex-list'),
]

