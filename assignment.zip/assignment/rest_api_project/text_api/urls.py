from .views import CustomUserDetail, ParagraphListCreate, ParagraphDetail, WordSearch
from django.urls import path
from rest_framework.schemas import get_schema_view

schema_view = get_schema_view(title="Your API", description="API Documentation")

urlpatterns = [
    path('user/<int:pk>/', CustomUserDetail.as_view()),
    path('paragraphs/', ParagraphListCreate.as_view()),
    path('paragraphs/<int:pk>/', ParagraphDetail.as_view()),
    path('user/<int:pk>/', CustomUserDetail.as_view()),
    path('paragraphs/', ParagraphListCreate.as_view()),
    path('paragraphs/<int:pk>/', ParagraphDetail.as_view()),
    path('search/', WordSearch.as_view()),  # Add search endpoint
    path('user/<int:pk>/', CustomUserDetail.as_view()),
    path('paragraphs/', ParagraphListCreate.as_view()),
    path('search/', WordSearch.as_view()),
    path('swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
]
