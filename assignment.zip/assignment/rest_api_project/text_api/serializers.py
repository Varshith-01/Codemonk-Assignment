from rest_framework import serializers
from .models import CustomUser, Paragraph, WordIndex
from django.db.models import Count
from django.db.models.functions import Lower
from rest_framework.response import Response
from rest_framework.generics import ListAPIView

class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'name', 'email', 'dob', 'createdAt', 'modifiedAt']


class ParagraphSerializer(serializers.ModelSerializer):
    class Meta:
        model = Paragraph
        fields = ['id', 'content', 'created_at']


class WordIndexSerializer(serializers.ModelSerializer):
    class Meta:
        model = WordIndex
        fields = ['id', 'word', 'paragraph']


class WordSearch(ListAPIView):
    serializer_class = ParagraphSerializer

    def get_queryset(self):
        # Extract the word to search from the query parameters
        word = self.request.query_params.get('word', '').lower()

        # Check if a word is provided
        if word:
            # Annotate each paragraph with the count of occurrences of the search word
            queryset = Paragraph.objects.annotate(
                word_count=Count('wordindex', filter=Lower('wordindex__word') == word)
            ).order_by('-word_count')[:10]  # Retrieve top 10 paragraphs
            return queryset
        else:
            # If no word is provided, return an empty queryset
            return Paragraph.objects.none()

    def list(self, request, *args, **kwargs):
        # Get the queryset of paragraphs containing the search word
        queryset = self.get_queryset()

        # Serialize the queryset
        serializer = self.get_serializer(queryset, many=True)

        # Debugging: Print the serialized data to console
        print("Serialized data:", serializer.data)

        # Return the serialized data as a response
        return Response(serializer.data)
