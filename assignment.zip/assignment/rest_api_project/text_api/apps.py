from django.apps import AppConfig


class TextApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'text_api'
