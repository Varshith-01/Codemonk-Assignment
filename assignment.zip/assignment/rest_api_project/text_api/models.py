from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

class CustomUserManager(BaseUserManager):
    def create_user(self, email, name, password=None, dob=None):
        # Ensure that email and name are provided
        if not email:
            raise ValueError('Users must have an email address')
        if not name:
            raise ValueError('Users must have a name')

        # Create a new user instance with provided attributes
        user = self.model(
            email=self.normalize_email(email),  # Normalize email address
            name=name,
            dob=dob,
        )

        # Set password and save the user to the database
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, name, password):
        # Create a superuser with admin privileges
        user = self.create_user(
            email=self.normalize_email(email),
            password=password,
            name=name,
        )
        user.is_admin = True
        user.save(using=self._db)
        return user

class CustomUser(AbstractBaseUser):
    # Define fields for custom user model
    id = models.AutoField(primary_key=True)
    email = models.EmailField(verbose_name="email", max_length=60, unique=True)
    name = models.CharField(max_length=30)
    dob = models.DateField(blank=True, null=True)
    createdAt = models.DateTimeField(auto_now_add=True)
    modifiedAt = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)

    USERNAME_FIELD = 'email'  # Use email as the unique identifier for authentication
    REQUIRED_FIELDS = ['name']  # Require name as a mandatory field

    objects = CustomUserManager()  # Manager for custom user model

    def __str__(self):
        return self.email

    def has_perm(self, perm, obj=None):
        return True  # User has permissions to perform any action by default

    def has_module_perms(self, app_label):
        return True  # User has permissions to access any app by default

    @property
    def is_staff(self):
        return self.is_admin  # User is considered staff if they are an admin

class Paragraph(models.Model):
    # Model to represent paragraphs of text
    id = models.AutoField(primary_key=True)
    content = models.TextField()  # Content of the paragraph
    created_at = models.DateTimeField(auto_now_add=True)  # Timestamp when paragraph is created

class WordIndex(models.Model):
    # Model to index words against paragraphs
    id = models.AutoField(primary_key=True)
    word = models.CharField(max_length=255)  # Word to be indexed
    paragraph = models.ForeignKey(Paragraph, on_delete=models.CASCADE)  # Reference to the paragraph
