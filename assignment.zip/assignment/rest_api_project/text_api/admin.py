from django.contrib import admin
from .models import CustomUser, Paragraph, WordIndex

# Register your models here.
admin.site.register(CustomUser)
admin.site.register(Paragraph)
admin.site.register(WordIndex)
