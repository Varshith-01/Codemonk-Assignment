from rest_framework.permissions import IsAuthenticated
from django.db.models import Count
from django.db.models.functions import Lower
from .models import CustomUser, Paragraph, WordIndex
from rest_framework.response import Response
from .serializers import CustomUserSerializer, ParagraphSerializer
from rest_framework import generics, permissions, status
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi

class CustomUserDetail(generics.RetrieveAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

class ParagraphListCreate(generics.ListCreateAPIView):
    queryset = Paragraph.objects.all()
    serializer_class = ParagraphSerializer
    permission_classes = [IsAuthenticated]

    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'content': openapi.Schema(type=openapi.TYPE_STRING)
        }
    ))
    def post(self, request, *args, **kwargs):
        data = request.data
        content = data.get('content', '')
        if content.strip():  # Check if content is not empty
            # Tokenize paragraphs and index words
            paragraphs = content.split('\n\n')
            for paragraph_content in paragraphs:
                paragraph = Paragraph.objects.create(content=paragraph_content)
                words = paragraph_content.lower().split()
                for word in words:
                    WordIndex.objects.create(word=word, paragraph=paragraph)
            return Response({'message': 'Paragraphs saved and words indexed successfully'}, status=status.HTTP_201_CREATED)
        else:
            return Response({'error': 'Content cannot be empty'}, status=status.HTTP_400_BAD_REQUEST)

class WordSearch(generics.ListAPIView):
    serializer_class = ParagraphSerializer
    permission_classes = [IsAuthenticated]

    @swagger_auto_schema(manual_parameters=[
        openapi.Parameter('word', openapi.IN_QUERY, description="Word to search for", type=openapi.TYPE_STRING)
    ])
    def get(self, request, *args, **kwargs):
        word = self.request.query_params.get('word', '').lower()
        if word:
            # Search for word in paragraphs and return top 10 paragraphs
            queryset = Paragraph.objects.annotate(word_count=Count('wordindex', filter=Lower('wordindex__word') == word)).order_by('-word_count')[:10]
            return queryset
        else:
            return Paragraph.objects.none()  # Return empty queryset if no word is provided
