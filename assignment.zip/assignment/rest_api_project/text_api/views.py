from rest_framework.permissions import IsAuthenticated
from .models import CustomUser, Paragraph, WordIndex
from .serializers import CustomUserSerializer, ParagraphSerializer, WordIndexSerializer
from rest_framework import generics, permissions, status
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from rest_framework.views import APIView
from django.db.models import Count
from django.db.models.functions import Lower
from rest_framework.response import Response

class CustomUserDetail(generics.RetrieveAPIView):
    """
    Retrieves details of a specific user.
    """
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

class ParagraphListCreate(generics.ListCreateAPIView):
    """
    Lists all paragraphs and creates new paragraphs.
    """
    queryset = Paragraph.objects.all()
    serializer_class = ParagraphSerializer
    permission_classes = [IsAuthenticated]

    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'content': openapi.Schema(type=openapi.TYPE_STRING)
        }
    ))
    def post(self, request, *args, **kwargs):
        """
        Creates new paragraphs and indexes words in the paragraphs.
        """
        data = request.data
        content = data.get('content', '')
        if content.strip():  # Check if content is not empty
            # Tokenize paragraphs and index words
            paragraphs = content.split('\n\n')
            for paragraph_content in paragraphs:
                paragraph = Paragraph.objects.create(content=paragraph_content)
                words = paragraph_content.lower().split()
                for word in words:
                    WordIndex.objects.create(word=word, paragraph=paragraph)
            return Response({'message': 'Paragraphs saved and words indexed successfully'}, status=status.HTTP_201_CREATED)
        else:
            return Response({'error': 'Content cannot be empty'}, status=status.HTTP_400_BAD_REQUEST)

class WordSearch(APIView):
    """
    Searches for a specific word in paragraphs.
    """
    permission_classes = [IsAuthenticated]

    @swagger_auto_schema(manual_parameters=[
        openapi.Parameter('word', openapi.IN_QUERY, description="Word to search for", type=openapi.TYPE_STRING)
    ])
    def get(self, request, *args, **kwargs):
        """
        Retrieves paragraphs containing the searched word.
        """
        word = request.query_params.get('word', '').lower()
        if word:
            # Search for word in paragraphs and return top 10 paragraphs
            queryset = Paragraph.objects.annotate(word_count=Count('wordindex', filter=Lower('wordindex__word') == word)).order_by('-word_count')[:10]
            serializer = ParagraphSerializer(queryset, many=True)
            return Response(serializer.data)
        else:
            return Response([])

    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'word': openapi.Schema(type=openapi.TYPE_STRING, description='Word to search for')
        }
    ))
    def post(self, request, *args, **kwargs):
        """
        Retrieves paragraphs containing the searched word.
        """
        word = request.data.get('word', '').lower()
        if word:
            # Search for word in paragraphs and return top 10 paragraphs
            queryset = Paragraph.objects.annotate(word_count=Count('wordindex', filter=Lower('wordindex__word') == word)).order_by('-word_count')[:10]
            serializer = ParagraphSerializer(queryset, many=True)
            return Response(serializer.data)
        else:
            return Response({'error': 'Word to search for is required'}, status=status.HTTP_400_BAD_REQUEST)

class UserListView(APIView):
    """
    Retrieves a list of all users.
    """
    def get(self, request):
        users = CustomUser.objects.all()
        serializer = CustomUserSerializer(users, many=True)
        return Response(serializer.data)

class ParagraphListView(APIView):
    """
    Retrieves a list of all paragraphs.
    """
    def get(self, request):
        paragraphs = Paragraph.objects.all()
        serializer = ParagraphSerializer(paragraphs, many=True)
        return Response(serializer.data)

class WordIndexListView(APIView):
    """
    Retrieves a list of all word indexes.
    """
    def get(self, request):
        word_indexes = WordIndex.objects.all()
        serializer = WordIndexSerializer(word_indexes, many=True)
        return Response(serializer.data)
